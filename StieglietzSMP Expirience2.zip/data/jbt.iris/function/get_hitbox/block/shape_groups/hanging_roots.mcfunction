data modify storage jbt.iris:data Shape set value [{min: [0.125d, 0.625d, 0.125d], max: [0.875d, 1.0d, 0.875d]}]
