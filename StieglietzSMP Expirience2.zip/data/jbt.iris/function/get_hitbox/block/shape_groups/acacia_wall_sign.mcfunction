execute if block ~ ~ ~ #jbt.iris:shape_groups/acacia_wall_sign[facing=north] run data modify storage jbt.iris:data Shape set value [{min: [0.0d, 0.28125d, 0.875d], max: [1.0d, 0.78125d, 1.0d]}]
execute if block ~ ~ ~ #jbt.iris:shape_groups/acacia_wall_sign[facing=south] run data modify storage jbt.iris:data Shape set value [{min: [0.0d, 0.28125d, 0.0d], max: [1.0d, 0.78125d, 0.125d]}]
execute if block ~ ~ ~ #jbt.iris:shape_groups/acacia_wall_sign[facing=west] run data modify storage jbt.iris:data Shape set value [{min: [0.875d, 0.28125d, 0.0d], max: [1.0d, 0.78125d, 1.0d]}]
execute if block ~ ~ ~ #jbt.iris:shape_groups/acacia_wall_sign[facing=east] run data modify storage jbt.iris:data Shape set value [{min: [0.0d, 0.28125d, 0.0d], max: [0.125d, 0.78125d, 1.0d]}]
