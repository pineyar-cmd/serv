data modify storage jbt.iris:data Shape set value [{min: [0.125d, 0.0d, 0.125d], max: [0.875d, 0.75d, 0.875d]}]
