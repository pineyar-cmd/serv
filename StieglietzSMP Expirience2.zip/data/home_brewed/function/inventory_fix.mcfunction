execute if items entity @s container.* minecraft:potion[potion_contents={potion:"minecraft:water"},!max_stack_size=8,!consumable={consume_seconds:0.8,animation:"drink",sound:"minecraft:entity.generic.drink",has_consume_particles:0b}] run function home_brewed:water_bottle_stack_fix

item modify entity @s container.* home_brewed:collections/start

advancement revoke @s only home_brewed:inventory_tweak