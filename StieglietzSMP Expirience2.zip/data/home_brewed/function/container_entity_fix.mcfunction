execute as @e[type=#home_brewed:container_entity,predicate=home_brewed:item_entity_true,distance=..10,sort=nearest] run item modify entity @s container.* home_brewed:full_item_check

advancement revoke @s only home_brewed:container_entity_detect