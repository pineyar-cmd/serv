execute store result score @s home_brewed_block_reach run attribute @s minecraft:block_interaction_range get 20
scoreboard players add @s home_brewed_block_reach 2

function home_brewed:container_fix/raycast

scoreboard players reset @s home_brewed_block_reach

item modify entity @s enderchest.* home_brewed:full_item_check

advancement revoke @s only home_brewed:container_detect