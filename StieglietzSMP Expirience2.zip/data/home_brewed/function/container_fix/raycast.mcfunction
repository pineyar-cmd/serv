execute anchored eyes if data block ^ ^ ^ Items run execute positioned ^ ^ ^ run function home_brewed:container_fix/item_check

scoreboard players remove @s home_brewed_block_reach 2

execute if score @s home_brewed_block_reach matches 1.. positioned ^ ^ ^0.2 run function home_brewed:container_fix/raycast