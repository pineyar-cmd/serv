execute unless block ~ ~ ~ minecraft:ender_chest run item modify block ~ ~ ~ container.* home_brewed:full_item_check

execute if block ~ ~ ~ #home_brewed:container_blocks[facing=north,type=left] run item modify block ~1 ~ ~ container.* home_brewed:full_item_check
execute if block ~ ~ ~ #home_brewed:container_blocks[facing=north,type=right] run item modify block ~-1 ~ ~ container.* home_brewed:full_item_check

execute if block ~ ~ ~ #home_brewed:container_blocks[facing=south,type=left] run item modify block ~-1 ~ ~ container.* home_brewed:full_item_check
execute if block ~ ~ ~ #home_brewed:container_blocks[facing=south,type=right] run item modify block ~1 ~ ~ container.* home_brewed:full_item_check

execute if block ~ ~ ~ #home_brewed:container_blocks[facing=east,type=left] run item modify block ~ ~ ~1 container.* home_brewed:full_item_check
execute if block ~ ~ ~ #home_brewed:container_blocks[facing=east,type=right] run item modify block ~ ~ ~-1 container.* home_brewed:full_item_check

execute if block ~ ~ ~ #home_brewed:container_blocks[facing=west,type=left] run item modify block ~ ~ ~-1 container.* home_brewed:full_item_check
execute if block ~ ~ ~ #home_brewed:container_blocks[facing=west,type=right] run item modify block ~ ~ ~1 container.* home_brewed:full_item_check