data remove storage home_brewed:count water_bottle

execute store result storage home_brewed:count water_bottle int 1 run clear @s minecraft:potion[potion_contents={potion:"minecraft:water"},!max_stack_size=8,!consumable={consume_seconds:0.8,animation:"drink",sound:"minecraft:entity.generic.drink",has_consume_particles:0b}] 0

clear @s minecraft:potion[potion_contents={potion:"minecraft:water"},!max_stack_size=8,!consumable={consume_seconds:0.8,animation:"drink",sound:"minecraft:entity.generic.drink",has_consume_particles:0b}]

loot give @s loot {pools:[{rolls:1,entries:[{type:"minecraft:item",name:"minecraft:potion",modifier:{type:"minecraft:sequence",functions:[{type:"minecraft:set_components",components:{"minecraft:potion_contents":{potion:"minecraft:water"},"minecraft:max_stack_size":8,"minecraft:consumable":{consume_seconds:0.8,animation:"drink",sound:"minecraft:entity.generic.drink",has_consume_particles:0b}}},{type:"minecraft:set_count",count:{type:"minecraft:storage",storage:"home_brewed:count",path:"water_bottle"}}]}}]}]}