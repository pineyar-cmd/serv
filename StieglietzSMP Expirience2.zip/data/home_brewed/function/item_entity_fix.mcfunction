item modify entity @s container.* home_brewed:full_item_check
tag @s add home_brewed_item_entity_fixed