execute if items entity @s player.cursor minecraft:lingering_potion unless entity @s[advancements={home_brewed:menu/brew_lingering=true}] run advancement grant @s only home_brewed:menu/brew_lingering

execute if items entity @s player.cursor *[minecraft:bundle_contents~{items:{contains:[{items:"minecraft:lingering_potion"}]}}] unless entity @s[advancements={home_brewed:menu/brew_lingering=true}] run advancement grant @s only home_brewed:menu/brew_lingering


execute if items entity @s player.cursor minecraft:splash_potion unless entity @s[advancements={home_brewed:menu/brew_splash=true}] run advancement grant @s only home_brewed:menu/brew_splash

execute if items entity @s player.cursor *[minecraft:bundle_contents~{items:{contains:[{items:"minecraft:splash_potion"}]}}] unless entity @s[advancements={home_brewed:menu/brew_splash=true}] run advancement grant @s only home_brewed:menu/brew_splash


advancement revoke @s only home_brewed:potion_brewed_check