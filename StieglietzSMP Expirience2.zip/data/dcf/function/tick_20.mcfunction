schedule function dcf:tick_20 20 replace
execute if data storage dcf:settings {enabled: true} run function dcf:check_open/tick
