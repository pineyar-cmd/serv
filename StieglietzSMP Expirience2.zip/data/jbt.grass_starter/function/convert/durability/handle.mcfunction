scoreboard players add $damage jbt.dummy 1
execute store result storage jbt:temp grass.damage int 1 run scoreboard players get $damage jbt.dummy
execute if predicate jbt.grass_starter:mainhand run return run function jbt.grass_starter:convert/durability/apply/mainhand with storage jbt:temp grass
execute if predicate jbt.grass_starter:offhand run return run function jbt.grass_starter:convert/durability/apply/offhand with storage jbt:temp grass
